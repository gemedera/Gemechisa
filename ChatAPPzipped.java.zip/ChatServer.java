import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {

    private static List<ClientHandler> clients =
            Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            System.out.println("Server listening on port 1234...");

            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler handler = new ClientHandler(socket);
                clients.add(handler);
                handler.start();
            }
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }

    static class ClientHandler extends Thread {
        private Socket socket;
        private BufferedReader in;
        private BufferedWriter out;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                out = new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream()));

                String msg;
                while ((msg = in.readLine()) != null) {
                    broadcast(msg, this);
                }
            } catch (IOException e) {
                System.out.println("Client disconnected");
            } finally {
                cleanup();
            }
        }

        private void broadcast(String msg, ClientHandler sender) {
            synchronized (clients) {
                for (ClientHandler c : clients) {
                    if (c != sender) { // send to others only (as before)
                        try {
                            c.out.write(msg);
                            c.out.newLine();
                            c.out.flush();
                        } catch (IOException ignored) {}
                    }
                }
            }
        }

        private void cleanup() {
            try {
                clients.remove(this);
                socket.close();
            } catch (IOException ignored) {}
        }
    }
}
