import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;

public class chatClient1 extends JFrame {

    private Socket socket;
    private BufferedWriter out;
    private BufferedReader in;

    private JTextArea chatArea;
    private JTextField messageField;

    public chatClient1() {
        setTitle("Client 1 - Gemechisa");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        chatArea = new JTextArea();
        chatArea.setEditable(false);

        messageField = new JTextField();

        add(new JScrollPane(chatArea), BorderLayout.CENTER);
        add(messageField, BorderLayout.SOUTH);

        messageField.addActionListener(e -> sendMessage());

        connect();
        setVisible(true);
    }

    private void connect() {
        try {
            socket = new Socket("localhost", 1234);
            out = new BufferedWriter(
                    new OutputStreamWriter(socket.getOutputStream()));
            in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream()));

            new Thread(this::receiveMessages).start();
        } catch (IOException e) {
            chatArea.append("Cannot connect to server\n");
        }
    }

    private void sendMessage() {
        try {
            String msg = messageField.getText().trim();
            if (!msg.isEmpty()) {
                out.write("Gemechisa: " + msg);
                out.newLine();
                out.flush();
                messageField.setText("");
            }
        } catch (IOException e) {
            chatArea.append("Send error\n");
        }
    }

    private void receiveMessages() {
        try {
            String msg;
            while ((msg = in.readLine()) != null) {
                chatArea.append(msg + "\n");
            }
        } catch (IOException e) {
            chatArea.append("Disconnected\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(chatClient1::new);
    }
}
