import java.rmi.Naming;
import javax.swing.*;
import java.awt.*;

public class calculatorClientGUI extends JFrame {

    private JTextField txtA, txtB, txtResult;
    private calculator calc;

    public calculatorClientGUI() {
        setTitle("RMI Calculator");
        setSize(350, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2, 5, 5));

        try {
            calc = (calculator) Naming.lookup(
                    "rmi://localhost/CalculatorService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "RMI Connection Failed");
        }

        txtA = new JTextField();
        txtB = new JTextField();
        txtResult = new JTextField();
        txtResult.setEditable(false);

        JButton btnAdd = new JButton("Add");
        JButton btnSub = new JButton("Subtract");
        JButton btnMul = new JButton("Multiply");
        JButton btnDiv = new JButton("Divide");

        add(new JLabel("Number 1:"));
        add(txtA);
        add(new JLabel("Number 2:"));
        add(txtB);

        add(btnAdd);
        add(btnSub);
        add(btnMul);
        add(btnDiv);

        add(new JLabel("Result:"));
        add(txtResult);

        btnAdd.addActionListener(e -> calculate("add"));
        btnSub.addActionListener(e -> calculate("sub"));
        btnMul.addActionListener(e -> calculate("mul"));
        btnDiv.addActionListener(e -> calculate("div"));
    }

    private void calculate(String op) {
        try {
            double a = Double.parseDouble(txtA.getText());
            double b = Double.parseDouble(txtB.getText());
            double result = 0;

            switch (op) {
                case "add": result = calc.add(a, b); break;
                case "sub": result = calc.subtract(a, b); break;
                case "mul": result = calc.multiply(a, b); break;
                case "div": result = calc.divide(a, b); break;
            }
            txtResult.setText(String.valueOf(result));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new calculatorClientGUI().setVisible(true);
        });
    }
}
