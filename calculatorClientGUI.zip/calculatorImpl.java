import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class calculatorImpl extends UnicastRemoteObject implements calculator {

    protected calculatorImpl() throws RemoteException {
        super();
    }

    public double add(double a, double b) {
        return a + b;
    }

    public double subtract(double a, double b) {
        return a - b;
    }

    public double multiply(double a, double b) {
        return a * b;
    }

    public double divide(double a, double b) throws RemoteException {
        if (b == 0)
            throw new RemoteException("Division by zero!");
        return a / b;
    }
}
